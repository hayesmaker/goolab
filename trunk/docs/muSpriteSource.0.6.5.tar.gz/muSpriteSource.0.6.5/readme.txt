
�Sprite is a vector graphics editor with timeline animation for ActionScript 3,
haXe Flash 9, Flex 3 MXML and Adobe AIR projects. Source code license is OSI BSD.

See readme folder for overview, build instructions and license details.

Open doc/index.html to view documentation pages. Samples for ActionScript 3 and
MXML are in doc/samples. Samples for haXe are in doc/samples/haxe.
Open doc/assets/muSprite.html to run �Sprite in your default browser or
run the mSprite.swf in a standalone Flash Player version 9 or later.

The Reference Manual is not included in this download as it can be accessed
online at http://musprite.sourceforge.net/ReferenceManual/index.html or
generated locally by installing NaturalDocs and following the readme/build.txt
instructions.

Download muSpriteIntroduction.zip and view the Flash presentations if you are new
to �Sprite. You can access the download section from: http://musprite.sourceforge.net

Building �Sprite itself is a one step process and fast if you use fcsh from Adobe.
But if you have Python 2.4+ with distutils installed then you can use the build.py
script to compile the �Sprite swf files. Optionally it can also build the AIR
package, generate reference documentation and create a distribution tarball. View
the build.py script in a text editor for details or run build --help for details.

Note that if you view the web pages in Internet Explorer 6 on Windows XP SP2 then
you get security alerts every time you open a local page with JavaScript or Flash.
Suggested remedy is to upgrade to the slick Safari browser, Opera or Firefox,
none of which has the issue.
