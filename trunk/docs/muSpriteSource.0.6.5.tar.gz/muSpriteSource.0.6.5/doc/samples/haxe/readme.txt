To compile haxe samples with static scenes from this directory type in a console:

haxe -cp hxclasses -swf-version 9 -swf-header 300:300:60:FFFFFF -main AppBlue -swf AppBlue.swf
haxe -cp hxclasses -swf-version 9 -swf-header 300:300:60:841B1B -main ClassicLogo -swf ClassicLogo.swf

For animated scenes add the precompiled animation library (on Windows replace / with \):

haxe -cp hxclasses -swf-version 9 -swf-lib AnimationLibrary/library.swf -swf-header 300:300:60:E2D0A7 -main BouncingBall -swf BouncingBall.swf
haxe -cp hxclasses -swf-version 9 -swf-lib AnimationLibrary/library.swf -swf-header 300:300:60:FFFFFF -main AnimatedMorningScene -swf AnimatedMorningScene.swf
haxe -cp hxclasses -swf-version 9 -swf-lib AnimationLibrary/library.swf -swf-header 300:300:60:FFFFFF -main HelloWorld -swf HelloWorld.swf
haxe -cp hxclasses -swf-version 9 -swf-lib AnimationLibrary/library.swf -swf-header 300:300:60:800080 -main LearningToFly -swf LearningToFly.swf


If you change the source code for the animation library then you have to recompile it.
You need both haxe and the Flex 3 SDK installed. First rename or delete the existing
AnimationLibrary and hxclasses directories. Then build a runtime shared library with Flex:

compc -source-path ../../../libraries -include-classes com/boostworthy/animation/sequence/Timeline com/boostworthy/animation/rendering/RenderMethod com/boostworthy/animation/easing/Transitions com/boostworthy/animation/sequence/tweens/Tween com/boostworthy/animation/sequence/tweens/PathTween com/boostworthy/animation/sequence/tweens/AdvancedTween com/boostworthy/geom/Path autotelicum/animation/TweenEx -directory=true -debug=false -output ./AnimationLibrary

Finally create haXe headers (on Windows replace / with \):

haxe --gen-hx-classes AnimationLibrary/library.swf

The animation library interface was built with haxe 1.17. You may have to regenerate it for newer versions.
