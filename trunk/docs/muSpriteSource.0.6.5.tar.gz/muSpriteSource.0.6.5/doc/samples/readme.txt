To compile samples from this directory with Flex 2 or 3 type in a console:

mxmlc --compiler.source-path+=../../libraries SampleName.as
