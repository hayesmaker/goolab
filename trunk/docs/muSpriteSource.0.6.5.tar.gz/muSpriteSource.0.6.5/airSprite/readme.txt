Title: AIR Desktop

Section: Installation

The Adobe AIR runtime is required for installation. See details at the Adobe website.

After download and install of the AIR runtime, launch the �Sprite air file and follow
the on-screen installation instructions. You do not need to uninstall when upgrading
versions. To uninstall run the air installer program and select the extra options.

Section: Features

The initial AIR version of �Sprite only adds very basic functionality compared to the
browser and Flash Player versions.

You can drag and drop class files on the desktop icon. The class files must have been
generated with �Sprite to give expected results. Try for example with the sample AS3
or haxe files. If you use a commandline to start �Sprite then you can give an initial
class file name there as well.

A settings file is created in the application local store (autotelicum.muSprite/Local Store)
with basic window state configuration information. On Windows it is placed at
> C:\Documents and Settings\[User Name]\Application Data\autotelicum.muSprite\Local Store
