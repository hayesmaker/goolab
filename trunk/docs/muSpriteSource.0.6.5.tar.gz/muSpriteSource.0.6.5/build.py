#!/usr/bin/env python

"""
    Build utility for muSprite.

    Command Line Usage:
        build [<options>...] [<version>]

    Options:
        -h, --help     Print usage information and exit.
        -a, --all      Build all i.e. also optional targets
        -r, --rebuild  Force rebuild of program targets

    Module Usage:
        Build utility for muSprite. Execute it from the muSprite directory.
        If <version> is not given then a 'Test' version name is used.

        It is a quick reuse of Python distutils so no make utilty has to be
        installed but it is not thorough - if in doubt use the rebuild option.

        The optional targets are:
            AIR package          - requires an internet connection
            Reference manual     - requires perl and NaturalDocs
            Distribution tarball - requires darcs installed and
                                   'darcs init' on muSprite directory

    Requirements:
        Python 2.4+ with distutils is required to run the script.
        Adobe Flex 3 SDK is required to build Flash swf files.
        If used on Windows then XP or later is required so forward slash works.

    Notes:
        On Windows if typing 'build' does not work then type 'build.py' or
        'set PATHEXT=%PATHEXT%;.py' or change PATHEXT in Control Panel/System.
"""

import getopt, os, subprocess, sys
from distutils import filelist, dep_util, util


pathNaturalDocs = '../NaturalDocs' # Edit this if ND is installed elsewhere


def executeCommand(cmd, message, abort=False):
    """Execute the command and args in the cmd array, print message on failure."""
    try:
        #print 'Command: ', cmd, '\n' # Uncomment to debug
        subprocess.call(cmd, shell=True)
    except:
        if abort:
            print "Error: " + cmd[0] + " failed or not found. " + message
            sys.exit()
        else:
            print "Warning: " + cmd[0] + " failed or not found. " + message


def buildTargets(version, rebuild, buildAll):
    """Build required and optional targets"""

    # Build preloader
    target = util.convert_path('doc/assets/mSprite.swf')
    sources = ['mSprite/mSprite-config.xml',
               'mSprite/mSprite.as',
               'libraries/autotelicum/utils/Color.as']
    preloaderOutOfDate = dep_util.newer_group(sources, target)
    if preloaderOutOfDate or rebuild:
        print ">>> Building " + target
        cmd = ['mxmlc', '-optimize', 'mSprite/mSprite.as']
        executeCommand(cmd, "Adobe Flex 3 SDK is required.", True)
    else:
        print target + " is up-to-date"


    # Build application
    target = util.convert_path('doc/assets/muSprite.swf')
    sources = filelist.findall('mSprite') + \
              filelist.findall('muSprite') + \
              filelist.findall('libraries')
    applicationOutOfDate = dep_util.newer_group(sources, target)
    if applicationOutOfDate or rebuild:
        print ">>> Building " + target
        cmd = ['mxmlc ', '-optimize', 'muSprite/muSprite.as']
        executeCommand(cmd, "Adobe Flex 3 SDK is required.", True)
    else:
        print target + " is up-to-date"

    # Return unless required to build optional targets
    if not buildAll:
        return

    # Build AIR application
    target = util.convert_path('airSprite/airSprite.swf')
    sources = filelist.findall('airSprite') + \
              filelist.findall('muSprite') + \
              filelist.findall('libraries')
    applicationOutOfDate = dep_util.newer_group(sources, target)
    if applicationOutOfDate or rebuild:
        print ">>> Building " + target
        cmd = ['mxmlc ', '+configname=air', '-optimize', 'airSprite/airSprite.as']
        executeCommand(cmd, "AIR version is only created when Adobe Flex 3 SDK is installed.", True)
    else:
        print target + " is up-to-date"

    # Build a self signed certificate
    certificate_file = 'airSprite/airSpriteCertificate.pfx'
    if os.path.exists(certificate_file) == False:
        print ">>> Creating application certificate"
        cmd = [ 'adt', '-certificate', '-cn', 'muSprite',
                '-ou', 'muSprite', '-o', 'autotelicum',
                '1024-RSA', certificate_file, 'opensource' ]
        executeCommand(cmd, "AIR certificate is only created when Adobe Flex 3 SDK is installed.")

    # Build AIR package
    mainapp = target
    target = util.convert_path('downloads/muSprite'+version+'.air')
    if dep_util.newer(mainapp, target) or \
       dep_util.newer('airSprite/airSprite-app.xml', target) or rebuild:
        print ">>> Building AIR package"
        cmd = [ 'adt', '-package', '-storetype', 'pkcs12',
                '-keystore', certificate_file,
                '-storepass', 'opensource',
                'downloads/muSprite' + version + '.air',
                'airSprite/airSprite-app.xml', mainapp,
                'icons/smallIcon.png', 'icons/mediumIcon.png',
                'icons/largeIcon.png', 'icons/hugeIcon.png' ]
        executeCommand(cmd, "AIR package is only created when Adobe Flex 3 SDK is installed.")


    # Build reference manual, NaturalDocs checks dependencies itself
    print ">>> Building Reference Manual"
    cmd = ['perl', pathNaturalDocs + '/NaturalDocs', '-i', 'readme', '-i', 'libraries',
          '-i', 'airSprite', '-i', 'muSprite', '-i', 'mSprite', '-img', 'ReferenceManualSetup',
          '-o', 'HTML', 'doc/ReferenceManual', '-p', 'ReferenceManualSetup',
          '-s', 'Default', 'DocStyle', '-do']
    executeCommand(cmd, "Reference manual is only created when Perl and NaturalDocs is installed.")


    # Build distribution tarball
    target = 'downloads/muSpriteSource'+version
    sources = filelist.findall('doc')
    if dep_util.newer_group(sources, target) or rebuild or \
       dep_util.newer(mainapp, target + '.tar.gz'):
        print ">>> Building Source Distribution"
        cmd = ['darcs', 'dist', '-d', target]
        executeCommand(cmd, "Distribution tarball is only created when Darcs is installed.")



def main():
    try:
        # Get process commandline options
        opts, args = getopt.getopt(sys.argv[1:], "har", ["help", "all", "rebuild"])
    except getopt.GetoptError:
        print __doc__
        sys.exit()
    buildAll = False
    rebuild = False
    for o, a in opts:
        if o in ("-h", "--help"):
            print __doc__
            sys.exit()
        if o in ("-a", "--all"):
            buildAll = True
        if o in ("-r", "--rebuild"):
            rebuild = True
    if len(args) == 0:
        version = "Test"
    elif len(args) == 1:
        version = args[0]
    else:
        print __doc__
        sys.exit()
    print ">>> Building version " + version
    # If version does not begin with a dot then prepend one
    if version[:1] not in '.':
        version = '.' + version
    buildTargets(version, rebuild, buildAll)

if __name__ == "__main__":
    main()
