Title: autotelicum

The autotelicum package consists of a set of light weight classes.
It aims to provide basic programmatic functionality for small
applications such as games and utilities where size is important.

The classes are in an alpha stage and reuse in other applications
are discouraged because their public interfaces may change.

Furthermore, the autotelicum classes are *not* intended to be used in
enterprise, e-commerce or multi-lingual applications. The Adobe Flex
framework classes already implement the required functionality for
such applications.

                         (see muSpriteLogo.png)
