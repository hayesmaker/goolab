Title: extras

The autotelicum extras package consist of classes that are not currently
used in �Sprite.

                         (see muSpriteLogo.png)
